const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

// ========== MIDDLEWARE ==========
app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true
}));
app.use(express.json());

// ========== IMPORT ROUTES ==========
const authRoutes = require("./routes/authRoutes"); // <-- ADDED

// ========== USE ROUTES ==========
app.use("/api/auth", authRoutes); // <-- ADDED

// Test route
app.get('/', (req, res) => {
    res.json({ 
        message: 'Milkshake Backend is running!',
        status: 'OK',
        timestamp: new Date().toISOString()
    });
});

// Orders endpoint
app.post('/api/orders/create', (req, res) => {
    console.log('📦 Order received:', req.body);
    
    res.json({
        success: true,
        message: 'Order created successfully!',
        orderId: Date.now(),
        data: req.body,
        serverTime: new Date().toISOString()
    });
});

// ========== START SERVER ==========
app.listen(PORT, () => {
    console.log(`
    🚀 Milkshake Backend Server Started!
    ✅ Port: ${PORT}
    ✅ URL: http://localhost:${PORT}
    🔑 Auth API: http://localhost:${PORT}/api/auth
    🧾 Orders API: http://localhost:${PORT}/api/orders/create
    `);
});

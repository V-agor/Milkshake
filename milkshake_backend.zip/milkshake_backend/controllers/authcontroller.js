const authModel = require("../models/authModel");

exports.signup = async (req, res) => {
    console.log("SIGNUP ROUTE HIT:", req.body);  // <-- ADD THIS

    try {
        const result = await authModel.signup(req.body);
        res.status(201).json(result);
    } catch (error) {
        console.error("SIGNUP ERROR:", error.message);
        res.status(400).json({ error: error.message });
    }
};


exports.login = async (req, res) => {
    try {
        const result = await authModel.login(req.body);
        res.status(200).json(result);
    } catch (error) {
        console.error("LOGIN ERROR:", error.message);
        res.status(401).json({ error: error.message });
    }
};
